from django.apps import AppConfig


class AppsConfig(AppConfig):
    name = 'apps'
